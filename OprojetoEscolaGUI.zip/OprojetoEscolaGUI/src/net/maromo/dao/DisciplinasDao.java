package net.maromo.dao;
import net.maromo.model.Disciplina;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DisciplinasDao {
    //Estabelecendo conexão
    Connection con = new ConnectionFactory().getConnection();
    public void inserirDado(Disciplina disciplina) throws SQLException {
        //Preparando o Statement
        String sql = "insert into Disciplinas " + " (cod, nome, disciplina)" + " values(?,?,?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        //Preenchimento de Valores
        stmt.setInt(1, disciplina.getCod());
        stmt.setString(2, disciplina.getNome());
        stmt.setString(3, disciplina.getDisciplina());

        //Execução
        stmt.execute();
        stmt.close();
    }
}

