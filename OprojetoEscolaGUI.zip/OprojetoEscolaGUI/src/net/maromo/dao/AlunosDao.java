package net.maromo.dao;

import net.maromo.model.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AlunosDao {
    //Estabelecendo conexão
    Connection con = new ConnectionFactory().getConnection();
    public void inserirDado(Aluno aluno) throws SQLException {
        //Preparando o Statement
        String sql = "insert into Aluno " + " (rm, nome, email, telefone, endereco, curso) " + " values(?,?,?,?,?,?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        //Preenchimento de Valores
        stmt.setInt(1, aluno.getRm());
        stmt.setString(2, aluno.getNome());
        stmt.setString(3, aluno.getEmail());
        stmt.setString(4, aluno.getTelefone());
        stmt.setString(5, aluno.getEndereco());
        stmt.setString(6, aluno.getCurso());
        //Execução
        stmt.execute();
        stmt.close();
    }
}
