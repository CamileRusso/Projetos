package net.maromo.view;

import net.maromo.dao.ProfessoresDao;
import net.maromo.model.Professor;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

public class formProfessor {
    private JButton gravarButton;
    private JButton sairButton;
    private JPanel professorPanel;
    private JTextField textCPF;
    private JTextField textNome;
    private JTextField textTelefone;
    private JTextField textEndereco;
    private JTextField textEmail;
    private JTextField textMateria;


    public formProfessor() {
        sairButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                SairDoCadastro();
            }
        });
        gravarButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Professor professor = new Professor();
                professor.setCpf(Integer.parseInt(textCPF.getText()));
                professor.setEmail(textEmail.getText());
                professor.setEndereco(textEndereco.getText());
                professor.setNome(textNome.getText());
                professor.setTelefone(textTelefone.getText());
                professor.setMateria(textMateria.getText());
                JOptionPane.showMessageDialog(
                        null,
                        "Dados do Professor \n " + professor.toString(),
                        "Cadastro efetuado com sucesso",
                        JOptionPane.INFORMATION_MESSAGE
                );
                ProfessoresDao dao = new ProfessoresDao();
                try{
                    ProfessoresDao.inserirDado(professor);
                } catch (SQLException ex){
                    JOptionPane.showMessageDialog(
                            null,
                            "Erro \n" + ex.toString(),
                            "Erro ao Cadastrar Professor",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }

                limparTela();
            }
        });
    }

    private void limparTela() {
        textEmail.setText("");
        textEndereco.setText("");
        textNome.setText("");
        textCPF.setText("");
        textTelefone.setText("");
        textMateria.setText("");
    }

    private void SairDoCadastro() {
        formMenu.telaAluno.dispose();
    }

    public JPanel getProfessorPanel() {
        return professorPanel;
    }
}
