package net.maromo.view;

import net.maromo.dao.DisciplinasDao;
import net.maromo.model.Disciplina;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

public class formDisciplina {
    private JPanel disciplinaPanel;
    private JTextField textNome;
    private JTextField textCodigo;
    private JButton gravarButton;
    private JButton sairButton;

    public formDisciplina() {
        gravarButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Disciplina disciplina = new Disciplina();
                disciplina.setCod(Integer.parseInt(textCodigo.getText()));
                disciplina.setDisciplina(textNome.getText());
                JOptionPane.showMessageDialog(
                        null,
                        "Dados da Discplina \n" + disciplina.toString(),
                        "Cadastro efetuado com sucesso.",
                        JOptionPane.INFORMATION_MESSAGE
                );
                DisciplinasDao dao = new DisciplinasDao();
                try{
                    dao.inserirDado(disciplina);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(
                            null,
                            "Erro \n" + ex.toString(),
                            "Erro ao Cadastrar Disciplina",
                            JOptionPane.INFORMATION_MESSAGE
                            );
                }
                limparTela();
            }
        });
        sairButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                formMenu.telaAluno.dispose();
            }
        });
    }

    private void limparTela() {
        textCodigo.setText("");
        textNome.setText("");
    }

    public JPanel getDisciplinaPanel() {
        return disciplinaPanel;
    }
}
