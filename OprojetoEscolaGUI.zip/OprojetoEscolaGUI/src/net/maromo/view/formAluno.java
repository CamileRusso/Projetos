package net.maromo.view;

import com.mysql.cj.protocol.x.XMessage;
import net.maromo.dao.AlunosDao;
import net.maromo.model.Aluno;
import net.maromo.model.Curso;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

public class formAluno {
    private JTextField textRM;
    private JTextField textNome;
    private JTextField textEmail;
    private JTextField textTelefone;
    private JTextField textEndereco;
    private JComboBox comboCurso;
    private JButton gravarButton;
    private JButton sairButton;
    private JPanel alunoPanel;

    public formAluno() {
        gravarButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Aluno aluno = new Aluno();
                aluno.setRm(Integer.parseInt(textRM.getText()));
                aluno.setNome(textNome.getText());
                aluno.setEmail(textEmail.getText());
                aluno.setTelefone(textTelefone.getText());
                aluno.setEndereco(textEndereco.getText());
                Curso curso = Curso.emdes;
                switch (comboCurso.getSelectedIndex()){
                    case 0:
                        curso = Curso.emdes;
                        break;
                    case 1:
                        curso = Curso.emia;
                        break;
                    case 2:
                        curso = Curso.eminfo;
                        break;
                    case 3:
                        curso = Curso.emad;
                        break;
                }
                aluno.setCurso(curso);
                //mostrar os dados como resultado
                JOptionPane.showMessageDialog(
                        null,
                        "Dados do Aluno \n" + aluno.toString(),
                        "Cadastro efetuado com sucesso.",
                        JOptionPane.INFORMATION_MESSAGE
                );
                AlunosDao dao = new AlunosDao();
                try{
                    dao.inserirDado(aluno);
                } catch (SQLException ex){
                    JOptionPane.showMessageDialog(
                            null,
                            "Erro \n" +ex.toString(),
                            "Erro ao Cadastrar Aluno",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                };
                limparTela();
            }
        });
        sairButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                SairDoCadastro();
            }
        });
    }

    private void SairDoCadastro() {
        formMenu.telaAluno.dispose();
    }

    private void limparTela() {
        textEmail.setText("");
        textEndereco.setText("");
        textNome.setText("");
        textRM.setText("");
        textTelefone.setText("");
        comboCurso.setSelectedIndex(0);
    }

    public JPanel getAlunoPanel() {
        return alunoPanel;
    }
}
