package net.maromo.model;

public enum Curso {
    emdes, emia, eminfo, emad
}
