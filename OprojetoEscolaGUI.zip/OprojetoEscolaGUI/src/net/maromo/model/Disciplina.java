package net.maromo.model;

public class Disciplina {
    private int cod;
    private String disciplina;
    private String nome;

    public int getCod() {
        return cod;
    }
    public void setCod(int cod) {
        this.cod = cod;
    }
    public String getDisciplina() {
        return disciplina;
    }
    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Disciplina{" +
                "cod=" + cod +
                ", disciplina='" + disciplina + '\'' +
                '}';
    }

}
